# wolfSSL Python Wrappers

The wolfSSL Python Wrappers have moved to their own separate trees. Details of which can be found below.

## wolfCrypt-py

wolfCrypt-py's source code can be found [on GitHub here](https://github.com/wolfSSL/wolfcrypt-py). The latest release is also available [on PyPi here](https://pypi.org/project/wolfcrypt/).

## wolfSSL-py

Alternatively if you need a wolfSSL Python wrapper, the source code can be found [on GitHub here](https://github.com/wolfSSL/wolfssl-py). Likewise the latest release can be found [on PyPi here](https://pypi.org/project/wolfssl/).
